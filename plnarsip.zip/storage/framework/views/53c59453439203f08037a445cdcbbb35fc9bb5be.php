<?php $__env->startSection('custom_css'); ?>
     <link href="<?php echo e(asset('css/dropzone.min.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page_header_title','Upload Sertifikat'); ?>
<?php $__env->startSection('page_title','Upload Sertifikat'); ?>
<?php $__env->startSection('page_child_title','Klik atau Drag and Drop Sertifikat '); ?>
<?php $__env->startSection('content'); ?>       
<ul class="breadcrumb">
<li ><a href="<?php echo e(url("arsip")); ?>" class="label label-primary">Arsip</a></li>
  <li ><a href="<?php echo e(url("arsip")); ?>/show/<?php echo e($id); ?>" class="label label-warning">Daftar Arsip </a></li>
  <li class="active" ><?php echo e($user->nama); ?></li>

</ul>

<form action="<?php echo e(url('arsip/sertifikat')); ?>" class="dropzone" id="myDropzoneSk">
  <?php echo e(csrf_field()); ?>

  <input type="hidden" name="id" value="<?php echo e($id); ?>">
</form>
<br>
  <a href="<?php echo e(url('arsip')); ?>/show/<?php echo e($id); ?>" class="btn btn-success btn-large ">Kembali</a>
      
 <?php $__env->stopSection(); ?> 
 <?php $__env->startSection('custom_js'); ?>
  <script src="<?php echo e(asset('js/dropzone.min.js')); ?>"></script>
  <script src="<?php echo e(asset('js/uploadconf.js')); ?>"></script>

 <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.parent', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>