<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title><?php echo $__env->yieldContent('page_header_title','Gentelella Alela!'); ?></title>

    <!-- Bootstrap -->
    <link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="<?php echo e(asset('css/font-awesome.min.css')); ?>" rel="stylesheet">
    <!-- NProgress -->
    <link href="<?php echo e(asset('css/nprogress.css')); ?>" rel="stylesheet">
    
    <!-- Custom Theme Style -->
    <?php echo $__env->yieldContent('custom_css'); ?>
    <link href="<?php echo e(asset('css/custom.min.css')); ?>" rel="stylesheet">
  </head>

  <body class="nav-md">
    <div class="container body">
      <div class="main_container">    
  <!-- page content -->
        <div class="col-md-12">
          <div class="col-middle">
            <div class="text-center text-center">
              <h1 class="error-number">403</h1>
              <h2>Sorry You Dont have Access</h2>
              
              </p>
              
            </div>
          </div>
        </div>

    <!-- jQuery -->
    <script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
    <!-- Bootstrap -->
    <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
    <!-- FastClick -->
    <script src="<?php echo e(asset('js/fastclick.js')); ?>"></script>
    <!-- NProgress -->
    <script src="<?php echo e(asset('js/nprogress.js')); ?>"></script>
    
    <!-- Custom Theme Scripts -->
     <?php echo $__env->yieldContent('custom_js'); ?>
    <script src="<?php echo e(asset('js/custom.min.js')); ?>"></script>
   
  </body>
</html>
