<?php $__env->startSection('page_header_title','Dashboard'); ?>
<?php $__env->startSection('custom_css'); ?>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('page_title','Dashboard'); ?>
<?php $__env->startSection('content'); ?>
<div class="alert alert-info alert-dismissible fade in" role="alert">
                 
                    <strong>Selamat Datang!</strong> <?php echo e(Auth::user()->nama); ?>

</div>
<div class="row tile_count">
	<div class="col-lg-4 tile_stats_count">
		<span class="count_top"><i class="fa fa-user"></i> Total Jumlah Sertifikat</span>
		<div class="count"><?php echo e($sertifikat->count()); ?></div>
	</div>
	
	<div class="col-lg-4 tile_stats_count">
		<span class="count_top"><i class="fa fa-user"></i> Total Jumlah SKPP dan SK</span>
		<div class="count green"><?php echo e($skpp->count()); ?></div>
	</div>
	<div class="col-lg-4 tile_stats_count">
		<span class="count_top"><i class="fa fa-user"></i> Total Jumlah MCU</span>
		<div class="count"><?php echo e($mcu->count()); ?></div>
	</div>
		<div class="col-lg-4 tile_stats_count">
		<span class="count_top"><i class="fa fa-user"></i> Total Jumlah SPPD</span>
		<div class="count"><?php echo e($sppd->count()); ?></div>
	</div>
	<div class="col-lg-4 tile_stats_count">
		<span class="count_top"><i class="fa fa-user"></i> Total Jumlah ADS</span>
		<div class="count"><?php echo e($ads->count()); ?></div>
	</div>
	<div class="col-lg-4 tile_stats_count">
		<span class="count_top"><i class="fa fa-user"></i> Total Jumlah SIC</span>
		<div class="count"><?php echo e($ads->count()); ?></div>
	</div>

	
</div>
<center>

</center>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('custom_js'); ?>
<script src="<?php echo e(asset('js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/dataTables.bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/dataTables.responsive.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/responsive.bootstrap.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.parent', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>