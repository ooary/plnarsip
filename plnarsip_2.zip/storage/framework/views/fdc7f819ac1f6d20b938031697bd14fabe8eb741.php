<?php $__env->startSection('custom_css'); ?>
<link href="<?php echo e(asset('css/dataTables.bootstrap.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('css/responsive.bootstrap.min.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page_header_title','Data Arsip ' .$user->nama); ?>
<?php $__env->startSection('page_title','Data Arsip '.$user->nama); ?>
<?php $__env->startSection('page_child_title','Daftar Data Arsip'); ?>
<?php $__env->startSection('content'); ?>
<ul class="breadcrumb">
  <li ><a href="<?php echo e(url("arsip")); ?>" class="label label-primary">Arsip</a></li>
  <li class="active" ><?php echo e($user->nama); ?></li>
</ul>
  <?php echo $__env->make('arsip.section._sertifikat', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('arsip.section._mcu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('arsip.section._ads', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('arsip.section._skpp', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('arsip.section._sppd', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('arsip.section._sic', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>




<?php $__env->stopSection(); ?>
<?php $__env->startSection('custom_js'); ?>
<script src="<?php echo e(asset('js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/dataTables.bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/dataTables.responsive.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/responsive.bootstrap.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.parent', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>