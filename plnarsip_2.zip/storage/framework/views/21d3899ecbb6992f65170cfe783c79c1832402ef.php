 <div class="x_title">
    <h2 style="font-weight: bold; ">SERTIFIKAT</h2>
    <div class="clearfix"></div>
  </div>
<table  class="table table-striped table-bordered dt-responsive nowrap datatable-responsive" cellspacing="0" width="100%">
  <thead>
    <tr>
      <th>No</th>
      <th>Nama Sertifikat</th>
      <th>Tanggal Upload</th>
      <th>Aksi</th>
    </tr>
  </thead>
  <tbody>
    <?php ($no=1); ?>
    <?php $__currentLoopData = $sertifikat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
    <tr>
      <td><?php echo e($no++); ?></td>
      <td><?php echo e($s->nama_sertifikat); ?></td>
      <td><?php echo e($s->created_at); ?></td>
      <td>
           <a href="<?php echo e(url('sertifikat')); ?>/<?php echo e($s->nama_sertifikat); ?>" class="btn btn-warning fa fa-download"></a>
  
      </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
  </tbody>
</table>