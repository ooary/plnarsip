<?php $__env->startSection('custom_css'); ?>
     <link href="<?php echo e(asset('css/parsley.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page_header_title','Data Pegawai'); ?>
<?php $__env->startSection('page_title','Data Pegawai'); ?>
<?php $__env->startSection('page_child_title','Daftar Data Pegawai'); ?>
<?php $__env->startSection('content'); ?>       
                    
   <?php echo e(Form::model($data,['route'=>['user.update',$data->id],'method' => 'put','data-parsley-validate'=>'parsley','class'=>'form-horizontal form-label-left','files'=>true])); ?>

		
      <?php echo $__env->make('user._form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
   <?php echo e(Form::close()); ?>

 <?php $__env->stopSection(); ?> 
 <?php $__env->startSection('custom_js'); ?>
  <script src="<?php echo e(asset('js/parsley.config.js')); ?>"></script>
  <script src="<?php echo e(asset('js/parsley.min.js')); ?>"></script>
 <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.parent', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>